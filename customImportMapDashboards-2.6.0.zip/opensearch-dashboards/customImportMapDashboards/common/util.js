"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.fromMBtoBytes = void 0;

/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
const fromMBtoBytes = sizeInMB => {
  return sizeInMB * 1024 * 1024;
};

exports.fromMBtoBytes = fromMBtoBytes;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInV0aWwudHMiXSwibmFtZXMiOlsiZnJvbU1CdG9CeXRlcyIsInNpemVJbk1CIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFFTyxNQUFNQSxhQUFhLEdBQUlDLFFBQUQsSUFBc0I7QUFDakQsU0FBT0EsUUFBUSxHQUFHLElBQVgsR0FBa0IsSUFBekI7QUFDRCxDQUZNIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIENvcHlyaWdodCBPcGVuU2VhcmNoIENvbnRyaWJ1dG9yc1xuICogU1BEWC1MaWNlbnNlLUlkZW50aWZpZXI6IEFwYWNoZS0yLjBcbiAqL1xuXG5leHBvcnQgY29uc3QgZnJvbU1CdG9CeXRlcyA9IChzaXplSW5NQjogbnVtYmVyKSA9PiB7XG4gIHJldHVybiBzaXplSW5NQiAqIDEwMjQgKiAxMDI0O1xufTtcbiJdfQ==